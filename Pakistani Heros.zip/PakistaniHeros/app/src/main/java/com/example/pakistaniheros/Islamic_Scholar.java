package com.example.pakistaniheros;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Islamic_Scholar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_islamic__scholar);
    }
}

package com.example.pakistaniheros;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Motivational_Speakers extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_motivational__speakers);
    }
}

package com.example.pakistaniheros.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.pakistaniheros.Cricket_Stars;
import com.example.pakistaniheros.Entertainment;
import com.example.pakistaniheros.Headlines;
import com.example.pakistaniheros.Islamic_Scholar;
import com.example.pakistaniheros.Live_Sports;
import com.example.pakistaniheros.Motivational_Speakers;
import com.example.pakistaniheros.R;
import com.example.pakistaniheros.TV_channels;
import com.example.pakistaniheros.Young_stars;

public class HomeFragment extends Fragment {

    private ImageView islamic_scholars,young_stars,entertainment,tv_channels,motivational_speakers,headlines,live_sport,cricket_stars;


    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        islamic_scholars = (ImageView) view.findViewById(R.id.islamic_scholars);
        young_stars = (ImageView) view.findViewById(R.id.young_stars);
        entertainment = (ImageView) view.findViewById(R.id.entertainment);
        tv_channels = (ImageView) view.findViewById(R.id.tv_channels);
        motivational_speakers = (ImageView) view.findViewById(R.id.motivational_speakers);
        headlines = (ImageView) view.findViewById(R.id.headlines);
        live_sport = (ImageView) view.findViewById(R.id.live_sport);
        cricket_stars = (ImageView) view.findViewById(R.id.cricket_stars);

       //First Image
        islamic_scholars.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Islamic_Scholar.class);
                startActivity(intent);
            }
        });

        //Second Image
        young_stars.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Young_stars.class);
                startActivity(intent);
            }
        });
        //Third Image
        entertainment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Entertainment.class);
                startActivity(intent);

            }
        });
        //FourthImage
        tv_channels.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), TV_channels.class);
                startActivity(intent);
            }
        });
        //Fifth Image
        motivational_speakers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Motivational_Speakers.class);
                startActivity(intent);
            }
        });
        //Sixth Image
        cricket_stars.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Cricket_Stars.class);
                startActivity(intent);
            }
        });
        //Seventh Image
        headlines.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Headlines.class);
                startActivity(intent);
            }
        });
        //Seventh Image
        live_sport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Live_Sports.class);
                startActivity(intent);
            }
        });
        return view;
    }
}
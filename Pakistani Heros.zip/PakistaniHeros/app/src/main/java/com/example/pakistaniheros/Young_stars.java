package com.example.pakistaniheros;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Young_stars extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_young_stars);
    }
}
